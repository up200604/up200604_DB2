<?php 
  include "conexion.php";

  $query = "SELECT * FROM film";

  if(isset($_POST['buscar']) && !empty($_POST['busqueda'])){
    $busqueda = $_POST['busqueda'];
    $query .= " WHERE name LIKE '%".$busqueda."%'";
  }

  $result = mysqli_query($mysqli, $query);
?>

<div class="">
    <?php
    if (mysqli_num_rows($result) > 0) {
        echo "<table>";
        echo "<tr><th>Category</th></tr>";
        while($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row["name"] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No se encontraron resultados</p>";
    }
    ?>
    <link rel="stylesheet" href="estilo2.css" type="text/css">
    <a href='index.html?id=" . $row["film_id"] . "' class='btn-agregar'>Regresar al inicio</a>
</div>