<?php 
include "conexion.php";

$title = $_POST['title'];
$description = $_POST['description'];
$release_year = $_POST['release_year'];
$language_id = $_POST['language_id'];

// Verificar si el idioma existe en la tabla 'language'
$check_language = "SELECT * FROM language WHERE language_id = '$language_id'";
$result = $mysqli->query($check_language);

if($result->num_rows == 0) {
  echo "<div class='error'>Error: El idioma no existe en la tabla 'language'. Agregue el idioma primero en la tabla 'language'.</div>";
} else {
  $sql = "INSERT INTO film (title, description, release_year, language_id) VALUES ('$title', '$description', '$release_year', '$language_id')";

  if ($mysqli->query($sql) === TRUE) {
    echo "<div class='success'>Nuevo registro creado satisfactoriamente</div>";

  } else {
    echo "<div class='error'>Error al crear el registro: " . $mysqli->error . "</div>";
  }
}

mysqli_close($mysqli);
//header('Location: index.php');
?>
    <link rel="stylesheet" href="estilo4.css" type="text/css">
<a href='index.html?id=" . $row["film_id"] . "' class='btn-agregar'>Regresar al inicio</a>