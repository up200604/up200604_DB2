<?php
include "conexion.php";
$film_id = $_REQUEST['film_id'];
$title = $_POST['title'];
$description = $_POST['description'];
$mysqli->query("UPDATE film SET title = '$title', description = '$description' WHERE film_id = $film_id");
echo "<p class='mensaje'>Cambios exitosos</p>";
?>

<link rel="stylesheet" href="estilo6.css" type="text/css">
<a href='index.html' class='btn-regresar'>Regresar al inicio</a>