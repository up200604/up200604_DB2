<?php 
  include "conexion.php";

  $query = "SELECT * FROM film";

  if(isset($_POST['buscar']) && !empty($_POST['busqueda'])){
    $busqueda = $_POST['busqueda'];
    $query .= " WHERE title LIKE '%".$busqueda."%'";
  }

  $result = mysqli_query($mysqli, $query);
?>

<div class="tabla-peliculas">
    <?php
    if (mysqli_num_rows($result) > 0) {
        echo "<table>";
        echo "<tr><th>ID</th><th>Nombre</th><th>Descripción</th><th>Acciones</th></tr>";
        while($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row["film_id"] . "</td>";
            echo "<td>" . $row["title"] . "</td>";
            echo "<td>" . $row["description"] . "</td>";
            echo "<td><a href='editar.php?id=" . $row["film_id"] . "'>Editar</a> | <a href='eliminar.php?id=" . $row["film_id"] . "'>Eliminar</a></td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No se encontraron resultados</p>";
    }
    ?>
    <link rel="stylesheet" href="estilo2.css" type="text/css">
    <a href='insertar.html?id=" . $row["film_id"] . "' class='btn-agregar'>Agregar película</a>
    <a href='index.html?id=" . $row["film_id"] . "' class='btn-agregar'>Regresar al inicio</a>
</div>


