<?php
    include("conexion.php");
    $film_id = $_GET['id'];
    $query = "SELECT * FROM film WHERE film_id = $film_id";
    $resultado = mysqli_query($mysqli, $query);
    $row = mysqli_fetch_assoc($resultado);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Modificar pelicula</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        
        h1 {
            font-size: 28px;
            color: #333;
            margin-top: 40px;
            text-align: center;
        }
        
        form {
            width: 900px;
            margin: 40px auto;
            background-color: #fff;
            border-radius: 40px;
            padding: 200px;
            box-shadow: 0 0 100px rgba(0, 0, 0, 0.3);
        }
        
        label {
            display: block;
            font-size: 16px;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }
        
        input[type="text"] {
            display: block;
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        
        input[type="submit"] {
            background-color: #2980b9;
            color: #fff;
            border: none;
            border-radius: 4px;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
        }
        
        input[type="submit"]:hover {
            background-color: #2c3e50;
        }
    </style>
</head>
<body>
    <h1>Modificar pelicula</h1>
    <form action="actualizar.php" method="post">
        <label for="film_id">ID:</label>
        <input type="text" id="film_id" name="film_id" value="<?php echo $row['film_id']; ?>" readonly>
        <label for="title">Nombre:</label>
        <input type="text" name="title" id="title" value="<?php echo $row['title']; ?>">
        <label for="description">Descripcion:</label>
        <input type="text" name="description" id="description" value="<?php echo $row['description']; ?>">
        <input type="submit" value="Guardar cambios">
    </form>
</body>
</html>