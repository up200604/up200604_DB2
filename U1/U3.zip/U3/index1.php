<?php 
  include "conexion.php";

  $query = "SELECT * FROM actor";

  if(isset($_POST['buscar1']) && !empty($_POST['busqueda1'])){
    $busqueda1 = $_POST['busqueda1'];
    $query .= " WHERE first_name LIKE '%".$busqueda1."%'";
  }

  $result = mysqli_query($mysqli, $query);
?>

<?php 
  include "conexion.php";

  // Obtener los datos del actor y las películas en las que ha participado
  $query = "SELECT actor.first_name, film.title FROM film_actor
            INNER JOIN actor ON actor.actor_id = film_actor.actor_id
            INNER JOIN film ON film.film_id = film_actor.film_id";
  if(isset($_POST['buscar1']) && !empty($_POST['busqueda1'])){
    $busqueda1 = $_POST['busqueda1'];
    $query .= " WHERE actor.first_name LIKE '%".$busqueda1."%'";
  }
  $result = mysqli_query($mysqli, $query);
?>

<div class="tabla-peliculas">
    <?php
    if (mysqli_num_rows($result) > 0) {
        echo "<table>";
        echo "<tr><th>Nombre</th><th>Título</th></tr>";
        while($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row["first_name"] . "</td>";
            echo "<td>" . $row["title"] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No se encontraron resultados</p>";
    }
    ?>
</div>

    <link rel="stylesheet" href="estilo2.css" type="text/css">
    <a href='index.html?id=" . $row["film_id"] . "' class='btn-agregar'>Regresar al inicio</a>
</div>