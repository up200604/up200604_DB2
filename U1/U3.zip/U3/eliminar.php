<?php
include "conexion.php";
$film_id = $_GET['id'];
$sql = "DELETE FROM film WHERE film_id = $film_id";
$result = mysqli_query($mysqli, $sql);
if ($result) {
  echo "<p class='mensaje-exito'>La película fue eliminada exitosamente</p>";
} else {
  echo "<p class='mensaje-error'>Hubo un error al intentar eliminar la película</p>";
}
mysqli_close($mysqli);
//header('Location: index.php');

?>
<link rel="stylesheet" href="estilo5.css" type="text/css">
<a href='index.html' class='btn-regresar'>Regresar al inicio</a>
